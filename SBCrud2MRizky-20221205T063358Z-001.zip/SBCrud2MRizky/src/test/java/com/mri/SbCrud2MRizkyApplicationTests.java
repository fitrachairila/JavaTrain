package com.mri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbCrud2MRizkyApplicationTests {

	@Test
	void contextLoads() {
	}

}
