package com.mri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbCrud2MRizkyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbCrud2MRizkyApplication.class, args);
	}

}
