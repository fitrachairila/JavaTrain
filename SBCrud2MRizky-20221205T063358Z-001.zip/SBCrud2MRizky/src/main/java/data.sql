insert into m_barang(nama_barang,supplier,qty)
values
('LCD 22" Toshiba','PT.Indah Sejahtera', 100),
('DDR5 1Gb','PT.Glodok', 50),
('PSU 4000Watt','PT.Tegangan Tinggi', 15);

insert into m_users(users,password,islogin)
values
('mrizky','x',true);